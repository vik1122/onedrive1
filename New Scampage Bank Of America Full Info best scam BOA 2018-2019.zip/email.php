<?php

$email = "iq96999@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>